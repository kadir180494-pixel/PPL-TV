# PPL TV — Android TV Launcher Shortcut

Kişisel TCL / Android TV cihazında PPL TV sitesini tam ekranda açmak için küçük, bağımsız Android uygulaması. PPL TV ile resmî ilişkisi yoktur; yalnızca siteyi yükler.

## iPhone + GitHub ile ücretsiz derleme

1. iPhone Dosyalar uygulamasında ZIP'i aç.
2. GitHub'da yeni, tercihen **private** repository oluştur.
3. Proje dosyalarını GitHub web arayüzündeki **Add file → Upload files** ile yükle. `.github/workflows/build.yml` klasör yapısını mutlaka koru. Gizli dosyalar iPhone Dosyalar uygulamasında görünmeyebilir: gerekiyorsa workflow dosyasını GitHub web editöründe `.github/workflows/build.yml` yolu ile oluştur.
4. **Actions → Build Android TV APK → Run workflow** (veya push ile otomatik başlar).
5. Başarılı işlemden sonra Actions çalışmasındaki **Artifacts → PPL-TV-Android-TV-APK** dosyasını indirip ZIP'ten APK'yi çıkar.
6. APK'yi TV'ye aktar ve kur. Android 14 cihazında TV'nin bilinmeyen uygulama kurulum izni gerekecektir.

Bu ortamda Android SDK olmadığı için hazır APK burada derlenemedi. GitHub Actions derlemesi de henüz test edilmedi.

## Özellikler / sınırlamalar

- Android TV ana ekranında **PPL TV** olarak görünür; `https://online.ppltv.tv/` sayfasını WebView içinde açar.
- Video tam ekran API'sini desteklemeye çalışır, oturum WebView içinde korunabilir.
- Menü tuşu tarayıcıda açar; erişim sorunu olursa tarayıcı butonu gösterilir.
- Bazı DRM video siteleri ve kumanda hareketleri WebView'da çalışmayabilir. Böyle durumda resmî uygulama veya uygun tarayıcı gerekli olabilir.
- Kullanıcı adını ve şifreni uygulamaya gömmeyiz; yalnızca sitenin kendi giriş ekranına girersin.
