package com.personal.ppltv;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final String URL = "https://online.ppltv.tv/";
    private WebView webView;
    private FrameLayout root;
    private FrameLayout customViewContainer;
    private View customView;
    private WebChromeClient.CustomViewCallback customViewCallback;
    private boolean browserFallbackShown = false;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setSystemUiVisibility(5894 | 1024 | 512);
        root = new FrameLayout(this); root.setBackgroundColor(Color.rgb(15,18,30));
        setContentView(root);
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(15,18,30));
        webView.setFocusable(true);
        webView.setFocusableInTouchMode(true);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setSupportZoom(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        webView.setWebViewClient(new WebViewClient(){
            @Override public void onReceivedError(WebView view, android.webkit.WebResourceRequest req, android.webkit.WebResourceError err) {
                if (req.isForMainFrame()) showBrowserFallback();
            }
        });
        webView.setWebChromeClient(new WebChromeClient(){
            @Override public void onShowCustomView(View view, CustomViewCallback callback) {
                if (customView != null) { callback.onCustomViewHidden(); return; }
                customView=view; customViewCallback=callback;
                customViewContainer = new FrameLayout(MainActivity.this);
                customViewContainer.setBackgroundColor(Color.BLACK);
                customViewContainer.addView(view, new FrameLayout.LayoutParams(-1,-1));
                root.addView(customViewContainer, new FrameLayout.LayoutParams(-1,-1));
            }
            @Override public void onHideCustomView(){ hideCustomView(); }
        });
        root.addView(webView, new FrameLayout.LayoutParams(-1,-1));
        webView.loadUrl(URL);
    }
    private void hideCustomView(){
        if (customView != null){ root.removeView(customViewContainer); customView=null; customViewContainer=null;
            if (customViewCallback != null) customViewCallback.onCustomViewHidden(); customViewCallback=null; }
    }
    private void showBrowserFallback(){
        if(browserFallbackShown) return; browserFallbackShown=true;
        LinearLayout panel=new LinearLayout(this); panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(40,32,40,32); panel.setBackgroundColor(Color.rgb(22,27,45));
        TextView msg=new TextView(this); msg.setText("PPL TV burada açılmadı. TV tarayıcısında açmayı deneyin."); msg.setTextColor(Color.WHITE); msg.setTextSize(22);
        Button open=new Button(this); open.setText("TARAYICIDA AÇ");
        open.setOnClickListener(v -> openInBrowser());
        panel.addView(msg); panel.addView(open);
        FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(-2,-2, Gravity.CENTER);
        root.addView(panel,p); open.requestFocus();
    }
    private void openInBrowser(){
        try { startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(URL))); }
        catch(Exception e){ /* Browser unavailable */ }
    }
    @Override public boolean onKeyDown(int keyCode, KeyEvent event){
        if (keyCode==KeyEvent.KEYCODE_BACK) {
            if(customView!=null){ hideCustomView(); return true; }
            if(webView.canGoBack()){webView.goBack(); return true;}
        }
        if (keyCode==KeyEvent.KEYCODE_MENU){openInBrowser(); return true;}
        return super.onKeyDown(keyCode,event);
    }
    @Override protected void onDestroy(){ if(webView!=null){webView.destroy();} super.onDestroy(); }
}
